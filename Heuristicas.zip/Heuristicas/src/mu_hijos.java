
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;


public class mu_hijos {

	static int mu = 5;
	static int lambda =20;
	
	static Queue<Integer> poblacion= new LinkedList<Integer>();
	static int mejor= 0;
	static Queue<Integer> mejores =new LinkedList<Integer>();
	static int iteracion= 0;
	
	
	public static int algEvo(int mu, int lambda){
		for(int i =0; i<lambda; i++){
			int rand= generaIntAleatorio();
			
			poblacion.add(rand);
//			System.out.println(poblacion);
		}
		mejor=0;
//		System.out.println(poblacion.size());
		
		do{
		int i=0;
			for(i=0; i<poblacion.size();i++){
//				System.out.println("Individuo: "+i);
//				System.out.println(poblacion);
				System.out.println("fitnes del mejor sujeto: "+ fitness(mejor)+" fitnes del sujeto "+ poblacion.peek() +" : "+fitness(poblacion.peek()));
				if(mejor==0 || fitness(poblacion.peek())< fitness(mejor)){
					mejor= poblacion.poll();
					System.out.println("mejor local: "+mejor);
					mejores.add(mejor);
				}
				else{
					poblacion.remove();
				}
			}
			poblacion=mejores;
			iteracion++;
			System.out.println(iteracion);
//			System.out.println(poblacion);
//			for(int j=0;j<mejores.size();j++){
//				for(int k=0; k< (lambda/mu);k++){
//					mejores.remove();
//				}
//			}
			
//		iteracion--;
		}
		while(!(poblacion.size()!=0));
		
		return mejor;
		
	}
	private static double fitness(int i) {
		// TODO Auto-generated method stub
		Double sumacuadrados = Math.pow(mu, 2)+Math.pow(lambda, 2);
		Double sqrt= Math.sqrt(sumacuadrados);
		Double numerador=Math.pow(Math.sin(sqrt), 2)-0.5;
		Double denominador=Math.pow(1+0.001*sumacuadrados, 2);
		Double funcion = numerador/denominador;
		
		double fitness =i-funcion;
		return fitness;
		
		
	}
	private static int generaIntAleatorio() {
		// TODO Auto-generated method stub
		Random rand=new Random();
		int aleat = rand.nextInt(1000);
		return aleat;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int algEvo= algEvo(mu, lambda);
		System.out.println("Mejor"+algEvo);
	}

}
